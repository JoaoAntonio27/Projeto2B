export const info = [
 {
   nome:"Grupo 1",
   descricao: "Descrição do projeto 1",
   Curso: "Curso 1",
   integrantes:[
     "João",
     "Maria",
     "Pedro"
   ]
 },
 {
   nome:"Grupo 2",
   descricao:"Descrição do projeto 2",
   Curso: "Curso 2",
   integrantes:[
     "Ana",
     "Carla",
     "Felipe"
   ]
 },
 {
   nome:"Grupo 3",
   descricao:"Descrição do projeto 3",
   Curso: "Curso 3",
   integrantes:[
     "Lucas",
     "Beatriz",
     "João"
   ]
 },
 {
  nome:"Grupo 4",
  descricao:"Descrição do projeto 4",
  Curso: "Curso 4",
  integrantes:[
    "Renato",
    "Júlia",
    "Thiago"
  ]
}

]