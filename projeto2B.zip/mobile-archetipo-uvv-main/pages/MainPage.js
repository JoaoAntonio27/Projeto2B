import React, { useState } from 'react';
import { Text, SafeAreaView, StyleSheet, TouchableOpacity, View, ImageBackground, ScrollView } from 'react-native';

const grupos = [
  { id: '1', nome: 'Grupo 1', descricao: 'Descrição do projeto 1', curso: 'Curso 1', integrantes: 'João, Maria, Pedro' },
  { id: '2', nome: 'Grupo 2', descricao: 'Descrição do projeto 2', curso: 'Curso 2', integrantes: 'Ana, Carla, Felipe' },
  { id: '3', nome: 'Grupo 3', descricao: 'Descrição do projeto 3', curso: 'Curso 3', integrantes: 'Lucas, Beatriz, João' },
  { id: '4', nome: 'Grupo 4', descricao: 'Descrição do projeto 4', curso: 'Curso 4', integrantes: 'Renato, Júlia, Thiago' },
];

export default function GroupsPage() {
  const [expandedGroup, setExpandedGroup] = useState(null);

  const handleExpand = (groupId) => {
    setExpandedGroup(expandedGroup === groupId ? null : groupId);
  };

  return (
    <ImageBackground source={require('../assets/fundo.png')} style={styles.background} resizeMode="cover">
      <SafeAreaView style={styles.container}>
        <ScrollView contentContainerStyle={styles.groupsContainer}>
          {grupos.map((group) => (
            <View
              key={group.id}
              style={[
                styles.groupWrapper,
                expandedGroup === group.id && styles.expandedWrapper,
              ]}
            >
              <TouchableOpacity
                style={styles.groupBox}
                onPress={() => handleExpand(group.id)}
              >
                <Text style={styles.groupName}>{group.nome}</Text>
              </TouchableOpacity>

              {expandedGroup === group.id && (
                <View style={styles.expandedInfo}>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Descrição:</Text> {group.descricao}
                  </Text>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Curso:</Text> {group.curso}
                  </Text>
                  <Text style={styles.infoText}>
                    <Text style={styles.bold}>Integrantes:</Text> {group.integrantes}
                  </Text>

                  <TouchableOpacity
                    style={styles.closeButton}
                    onPress={() => handleExpand(group.id)}
                  >
                    <Text style={styles.closeButtonText}>X</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          ))}
        </ScrollView>
      </SafeAreaView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  groupsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingVertical: 20,
  },
  groupWrapper: {
    width: '45%',
    margin: 10,
  },
  expandedWrapper: {
    width: '100%', // Expande para ocupar toda a largura
    marginBottom: 20, // Garante espaçamento extra
  },
  groupBox: {
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#063970',
    borderRadius: 10,
  },
  groupName: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  expandedInfo: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    padding: 10,
    marginTop: 10,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 5,
  },
  bold: {
    fontWeight: 'bold',
  },
  closeButton: {
    marginTop: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6347',
    height: 30,
    width: 60,
    borderRadius: 5,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});
